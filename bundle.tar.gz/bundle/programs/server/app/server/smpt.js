(function(){Meteor.startup(function () {

});

})();
